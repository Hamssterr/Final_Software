﻿namespace webOrder
{
    partial class PaymentStatuscs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grdOrder = new System.Windows.Forms.DataGridView();
            this.bShow = new System.Windows.Forms.Button();
            this.bCancel = new System.Windows.Forms.Button();
            this.bPay = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdOrder)).BeginInit();
            this.SuspendLayout();
            // 
            // grdOrder
            // 
            this.grdOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOrder.Location = new System.Drawing.Point(61, 97);
            this.grdOrder.Name = "grdOrder";
            this.grdOrder.RowHeadersWidth = 51;
            this.grdOrder.RowTemplate.Height = 24;
            this.grdOrder.Size = new System.Drawing.Size(682, 208);
            this.grdOrder.TabIndex = 11;
            this.grdOrder.Click += new System.EventHandler(this.grdOrder_Click);
            // 
            // bShow
            // 
            this.bShow.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bShow.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bShow.Location = new System.Drawing.Point(61, 30);
            this.bShow.Name = "bShow";
            this.bShow.Size = new System.Drawing.Size(278, 52);
            this.bShow.TabIndex = 12;
            this.bShow.Text = "Show status of all orders";
            this.bShow.UseVisualStyleBackColor = false;
            this.bShow.Click += new System.EventHandler(this.bShow_Click);
            // 
            // bCancel
            // 
            this.bCancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCancel.Location = new System.Drawing.Point(353, 340);
            this.bCancel.Name = "bCancel";
            this.bCancel.Size = new System.Drawing.Size(186, 43);
            this.bCancel.TabIndex = 13;
            this.bCancel.Text = "Cancel";
            this.bCancel.UseVisualStyleBackColor = false;
            this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
            // 
            // bPay
            // 
            this.bPay.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bPay.Location = new System.Drawing.Point(557, 340);
            this.bPay.Name = "bPay";
            this.bPay.Size = new System.Drawing.Size(186, 43);
            this.bPay.TabIndex = 14;
            this.bPay.Text = "Pay";
            this.bPay.UseVisualStyleBackColor = false;
            this.bPay.Click += new System.EventHandler(this.bPay_Click);
            // 
            // PaymentStatuscs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 414);
            this.Controls.Add(this.bPay);
            this.Controls.Add(this.bCancel);
            this.Controls.Add(this.bShow);
            this.Controls.Add(this.grdOrder);
            this.Name = "PaymentStatuscs";
            this.Text = "PaymentStatuscs";
            ((System.ComponentModel.ISupportInitialize)(this.grdOrder)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView grdOrder;
        private System.Windows.Forms.Button bShow;
        private System.Windows.Forms.Button bCancel;
        private System.Windows.Forms.Button bPay;
    }
}