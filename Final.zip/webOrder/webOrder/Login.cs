﻿using saleManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace webOrder
{
    public partial class Login : Form
    {
        DataTable dt = new DataTable();

        public Login()
        {
            InitializeComponent();
        }

        private void bLogin_Click(object sender, EventArgs e)
        {
            if (txtAccount.Text == "")
            {
                MessageBox.Show("Please enter your account");
            }
            else if (txtPassword.Text == "")
            {
                MessageBox.Show("Please enter your password");
            }
            else
            {
                string sql = "select id from agent where account = '" + txtAccount.Text + "' and password = '" + txtPassword.Text + "'";
                dt = SQL.selectQuery(sql);


                if (dt.Rows.Count > 0)
                {
                    string idAgent = dt.Rows[0][0].ToString();

                    Main main = new Main(this, idAgent);
                    this.Hide();
                    main.Show();
                }
                else
                {
                    MessageBox.Show("Invalid account");
                }
            }
        }
    }
}
