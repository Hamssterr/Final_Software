﻿namespace webOrder
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bLogout = new System.Windows.Forms.Button();
            this.bOrderStatus = new System.Windows.Forms.Button();
            this.bOrder = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bLogout
            // 
            this.bLogout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bLogout.Location = new System.Drawing.Point(466, 169);
            this.bLogout.Name = "bLogout";
            this.bLogout.Size = new System.Drawing.Size(180, 40);
            this.bLogout.TabIndex = 3;
            this.bLogout.Text = "Log out";
            this.bLogout.UseVisualStyleBackColor = false;
            this.bLogout.Click += new System.EventHandler(this.bLogout_Click);
            // 
            // bOrderStatus
            // 
            this.bOrderStatus.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bOrderStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bOrderStatus.Location = new System.Drawing.Point(58, 142);
            this.bOrderStatus.Name = "bOrderStatus";
            this.bOrderStatus.Size = new System.Drawing.Size(338, 67);
            this.bOrderStatus.TabIndex = 1;
            this.bOrderStatus.Text = "OrderStatus";
            this.bOrderStatus.UseVisualStyleBackColor = false;
            this.bOrderStatus.Click += new System.EventHandler(this.bOrderStatus_Click);
            // 
            // bOrder
            // 
            this.bOrder.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bOrder.Location = new System.Drawing.Point(58, 48);
            this.bOrder.Name = "bOrder";
            this.bOrder.Size = new System.Drawing.Size(338, 67);
            this.bOrder.TabIndex = 0;
            this.bOrder.Text = "Order";
            this.bOrder.UseVisualStyleBackColor = false;
            this.bOrder.Click += new System.EventHandler(this.bOrder_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 243);
            this.ControlBox = false;
            this.Controls.Add(this.bOrderStatus);
            this.Controls.Add(this.bOrder);
            this.Controls.Add(this.bLogout);
            this.Name = "Main";
            this.Text = "Main";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bLogout;
        private System.Windows.Forms.Button bOrderStatus;
        private System.Windows.Forms.Button bOrder;
    }
}

