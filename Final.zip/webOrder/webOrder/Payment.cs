﻿using saleManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace webOrder
{
    public partial class Payment : Form
    {
        private string idAgent = "";
        private string idBill = "";

        DataTable dt = new DataTable();

        public Payment()
        {
            InitializeComponent();
        }

        public Payment(string idAgent, string idBill)
        {
            InitializeComponent();

            this.idAgent = idAgent;
            this.idBill = idBill;

            updateBill();

            displayOrder();
        }

        private void bBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public void updateBill()
        {
            string sql = "update bill set paymentStatus = 'paid'";

            SQL.actionQuery(sql);
        }

        public void displayOrder()
        {
            string sql = "select b.id, b.foundDate, o.paymentMethod ,b.deliveryStatus, b.paymentStatus from bill b, orders o where b.idOrder = o.id and o.idAgent = '" + idAgent + "'";

            dt = SQL.selectQuery(sql);

            grdInformation.DataSource = dt;
        }
    }
}
