﻿using saleManagement;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace webOrder
{
    public partial class PaymentStatuscs : Form
    {
        private string idAgent = "";
        private string idBill = "";
        private string paymentStatus = "";

        DataTable dt = new DataTable();

        public PaymentStatuscs()
        {
            InitializeComponent();
        }

        public PaymentStatuscs(string id)
        {
            InitializeComponent();

            this.idAgent = id;

            grdOrder.Enabled = false;


            bPay.Enabled = false;
        }

        private void bShow_Click(object sender, EventArgs e)
        {
            showOrders();
        }

        public void showOrders()
        {
            grdOrder.Enabled = true;

            string sql = "select b.id, b.foundDate, o.paymentMethod ,b.deliveryStatus, b.paymentStatus from bill b, orders o where b.idOrder = o.id and o.idAgent = '" + idAgent + "'";

            dt = SQL.selectQuery(sql);

            grdOrder.DataSource = dt;
        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grdOrder_Click(object sender, EventArgs e)
        {
            idBill = grdOrder.CurrentRow.Cells[0].Value.ToString();

            paymentStatus = grdOrder.CurrentRow.Cells[4].Value.ToString();

            bPay.Enabled = true;
        }

        private void bPay_Click(object sender, EventArgs e)
        {
            if(idBill == "" || paymentStatus == "")
            {
                return;
            }

            if(paymentStatus == "paid")
            {
                MessageBox.Show("Order has been paid");
                return;
            }

            if (MessageBox.Show("Do you want to PAY for the order", "pay order", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }

            Payment payment = new Payment(idAgent, idBill);
            payment.ShowDialog();

            idBill = "";

            showOrders();
        }
    }
}
