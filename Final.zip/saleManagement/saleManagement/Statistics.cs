﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace saleManagement
{
    public partial class Statistics : Form
    {
        DataTable dt = new DataTable();

        public Statistics()
        {
            InitializeComponent();

            cbStatistics.DropDownStyle = ComboBoxStyle.DropDownList;

            loadComboBox();
        }

        public void loadComboBox()
        {
            List<string> list = new List<string>();
            list.Add("Incoming stock report");
            list.Add("Outgoing stock report");
            list.Add("Best-selling");
            list.Add("Revenue report");

            cbStatistics.DataSource = list;

        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bView_Click(object sender, EventArgs e)
        {
            int month = int.Parse(txtMonth.Value.ToString());
            int year = int.Parse(txtYear.Value.ToString());

            if (cbStatistics.SelectedIndex == 0)
            {
                dt = SQL.viewIncomingStock(month, year);
            }
            else if(cbStatistics.SelectedIndex == 1)
            {
                dt = SQL.viewOutcomingStock(month, year);
            }
            else if(cbStatistics.SelectedIndex == 2)
            {
                dt = SQL.viewBestSelling(month, year);
            }
            else if (cbStatistics.SelectedIndex == 3)
            {
                dt = SQL.viewRevenueMonthly(month, year);
                if (dt.Rows[0][0].ToString() == "")
                {
                    dt.Rows[0][0] = "0";
                }
            }

            grdStatistics.DataSource = dt;
        }
    }
}
