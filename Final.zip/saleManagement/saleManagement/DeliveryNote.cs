﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.IO;
using System.Net.NetworkInformation;

namespace saleManagement
{
    public partial class DeliveryNote : Form
    {
        private string idAccountant = "";
        private string idOrder = "";
        private string idBill = "";

        DataTable dt = new DataTable();
        public DeliveryNote()
        {
            InitializeComponent();
        }

        public DeliveryNote(string id)
        {
            InitializeComponent();

            this.idAccountant = id;

            grdOrder.Enabled = false;

            bCreateBill.Enabled = false;

            grdBill.Enabled = false;

            bDelete.Enabled = false;

            bPrintBill.Enabled = false;

            loadPaymentStatus();
        }

        public void showOrder()
        {
            dt = SQL.selectQuery("select * from Orders");

            grdOrder.DataSource = dt;
        }

        public void showBill()
        {
            dt = SQL.selectQuery("select * from Bill");

            grdBill.DataSource = dt;
        }

        public void loadPaymentStatus()
        {
            cbPaymentStatus.DropDownStyle = ComboBoxStyle.DropDownList;

            List<string> list = new List<string>();
            list.Add("Unpaid");
            list.Add("Paid");

            cbPaymentStatus.DataSource = list;

            cbPaymentStatus.Enabled = false;
        }

        private void bShowOrder_Click(object sender, EventArgs e)
        {
            grdOrder.Enabled = true;

            showOrder();
        }

        private void bShowBill_Click(object sender, EventArgs e)
        {
            grdBill.Enabled = true;

            showBill();
        }

        private void grdOrder_Click(object sender, EventArgs e)
        {
            idOrder = grdOrder.CurrentRow.Cells[0].Value.ToString();

            bCreateBill.Enabled = true;
        }

        private void bCreateBill_Click(object sender, EventArgs e)
        {
            if(idOrder == "")
            {
                return;
            }

            string sql = "select * from bill";

            dt = SQL.selectQuery(sql);

            string id = "bi" + (dt.Rows.Count + 1);

            DateTime now = DateTime.Now;

            string foundDate = now.ToString();

            sql = "insert into bill values('" + id + "', '" + foundDate + "', '" + idOrder + "', '" + idAccountant + "', 'not yet delivered', 'unpaid')";

            SQL.actionQuery(sql);

            bCreateBill.Enabled = false;

            idOrder = "";

            showBill();
        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void grdBill_Click(object sender, EventArgs e)
        {
            idBill = grdBill.CurrentRow.Cells[0].Value.ToString();

            bDelete.Enabled = true;

            bPrintBill.Enabled = true;

            cbPaymentStatus.Enabled = true;
        }

        private void bDelete_Click(object sender, EventArgs e)
        {
            if(idBill == "")
            {
                return;
            }

            string sql = "delete from Bill where id = '" + idBill + "'";

            SQL.actionQuery(sql);

            bDelete.Enabled = false;

            showBill();
        }

        private void bPrintBill_Click(object sender, EventArgs e)
        {
            if(idBill == "")
            {
                return;
            }

            if (MessageBox.Show("Do you want to PRINT DELIVERY NOTE", "print delivery note", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }

            string sql = "select name from accountant where id = '" + idAccountant + "'";

            string nameAccountant = SQL.selectQuery(sql).Rows[0][0].ToString();

            sql = "select * from bill where id ='" + idBill + "'";

            dt = SQL.selectQuery(sql);

            sql = "select name from agent a, orders o where a.id = o.idAgent and o.id = '" + dt.Rows[0]["idOrder"].ToString() + "'";

            string nameAgent = SQL.selectQuery(sql).Rows[0][0].ToString();

            sql = "select totalPrice from orders where id = '" + dt.Rows[0]["idOrder"].ToString() + "'";

            string totalPrice = SQL.selectQuery(sql).Rows[0][0].ToString();

            Document document = new Document();
            string path = "deliveryNote.pdf";
            PdfWriter.GetInstance(document, new FileStream(path, FileMode.Create));
            document.Open();

            Paragraph p = new Paragraph("DELIVERY BILL INFORMATION");
            document.Add(p);

            p = new Paragraph("Id bill: " + idBill);
            document.Add(p);

            p = new Paragraph("Date found bill: " + dt.Rows[0]["foundDate"].ToString());
            document.Add(p);

            p = new Paragraph("Name accountant: " + nameAccountant);
            document.Add(p);

            p = new Paragraph("Name agent: " + nameAgent);
            document.Add(p);

            p = new Paragraph("Delivery status: being transfer");
            document.Add(p);

            p = new Paragraph("Payment status: " + dt.Rows[0]["paymentStatus"].ToString());
            document.Add(p);

            p = new Paragraph("\nDELIVERY ITEMS LIST");
            document.Add(p);

            sql = "select i.name, price, quantity from item i, detailOrder d where i.id = d.idItem and d.idOrder = '" + dt.Rows[0]["idOrder"].ToString() + "'";

            dt = SQL.selectQuery(sql);

            p = new Paragraph("Name / Price / Quantity");
            document.Add(p);

            foreach (DataRow row in dt.Rows)
            {
                string line = "- " + row["name"].ToString() + " / " + row["price"].ToString() + "VND / " + row["quantity"].ToString();
                p = new Paragraph(line);
                document.Add(p);
            }

            p = new Paragraph("=> Total price: " + totalPrice + "VND");
            document.Add(p);

            document.Close();


            sql = "update bill set deliveryStatus = 'being transfer' where id = '" + idBill + "'";

            SQL.actionQuery(sql);

            MessageBox.Show("Print DELIVERY NOTE successfully");

            showBill();
        }

        private void cbPaymentStatus_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(idBill == "")
            {
                return;
            }

            string sql = "";
            if (cbPaymentStatus.SelectedIndex == 0)
            {
                sql = "update bill set paymentStatus = 'unpaid' where id = '" + idBill + "'";
            }
            else if(cbPaymentStatus.SelectedIndex == 1)
            {
                sql = "update bill set paymentStatus = 'paid' where id = '" + idBill + "'";
            }

            if(sql == "")
            {
                return;
            }
            SQL.actionQuery(sql);

            showBill();
        }
    }
}
