﻿namespace saleManagement
{
    partial class DeliveryNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bShowOrder = new System.Windows.Forms.Button();
            this.grdOrder = new System.Windows.Forms.DataGridView();
            this.bShowBill = new System.Windows.Forms.Button();
            this.bCreateBill = new System.Windows.Forms.Button();
            this.grdBill = new System.Windows.Forms.DataGridView();
            this.bDelete = new System.Windows.Forms.Button();
            this.bCancel = new System.Windows.Forms.Button();
            this.bPrintBill = new System.Windows.Forms.Button();
            this.cbPaymentStatus = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.grdOrder)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdBill)).BeginInit();
            this.SuspendLayout();
            // 
            // bShowOrder
            // 
            this.bShowOrder.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bShowOrder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bShowOrder.Location = new System.Drawing.Point(30, 27);
            this.bShowOrder.Name = "bShowOrder";
            this.bShowOrder.Size = new System.Drawing.Size(181, 52);
            this.bShowOrder.TabIndex = 0;
            this.bShowOrder.Text = "Show all orders";
            this.bShowOrder.UseVisualStyleBackColor = false;
            this.bShowOrder.Click += new System.EventHandler(this.bShowOrder_Click);
            // 
            // grdOrder
            // 
            this.grdOrder.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdOrder.Location = new System.Drawing.Point(30, 85);
            this.grdOrder.Name = "grdOrder";
            this.grdOrder.RowHeadersWidth = 51;
            this.grdOrder.RowTemplate.Height = 24;
            this.grdOrder.Size = new System.Drawing.Size(845, 151);
            this.grdOrder.TabIndex = 5;
            this.grdOrder.Click += new System.EventHandler(this.grdOrder_Click);
            // 
            // bShowBill
            // 
            this.bShowBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bShowBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bShowBill.Location = new System.Drawing.Point(30, 276);
            this.bShowBill.Name = "bShowBill";
            this.bShowBill.Size = new System.Drawing.Size(181, 52);
            this.bShowBill.TabIndex = 2;
            this.bShowBill.Text = "Show all bills";
            this.bShowBill.UseVisualStyleBackColor = false;
            this.bShowBill.Click += new System.EventHandler(this.bShowBill_Click);
            // 
            // bCreateBill
            // 
            this.bCreateBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bCreateBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCreateBill.Location = new System.Drawing.Point(726, 242);
            this.bCreateBill.Name = "bCreateBill";
            this.bCreateBill.Size = new System.Drawing.Size(149, 52);
            this.bCreateBill.TabIndex = 1;
            this.bCreateBill.Text = "Create bill";
            this.bCreateBill.UseVisualStyleBackColor = false;
            this.bCreateBill.Click += new System.EventHandler(this.bCreateBill_Click);
            // 
            // grdBill
            // 
            this.grdBill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdBill.Location = new System.Drawing.Point(30, 334);
            this.grdBill.Name = "grdBill";
            this.grdBill.RowHeadersWidth = 51;
            this.grdBill.RowTemplate.Height = 24;
            this.grdBill.Size = new System.Drawing.Size(845, 151);
            this.grdBill.TabIndex = 6;
            this.grdBill.Click += new System.EventHandler(this.grdBill_Click);
            // 
            // bDelete
            // 
            this.bDelete.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bDelete.Location = new System.Drawing.Point(726, 491);
            this.bDelete.Name = "bDelete";
            this.bDelete.Size = new System.Drawing.Size(149, 52);
            this.bDelete.TabIndex = 3;
            this.bDelete.Text = "Delete bill";
            this.bDelete.UseVisualStyleBackColor = false;
            this.bDelete.Click += new System.EventHandler(this.bDelete_Click);
            // 
            // bCancel
            // 
            this.bCancel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bCancel.Location = new System.Drawing.Point(726, 597);
            this.bCancel.Name = "bCancel";
            this.bCancel.Size = new System.Drawing.Size(127, 52);
            this.bCancel.TabIndex = 4;
            this.bCancel.Text = "Cancel";
            this.bCancel.UseVisualStyleBackColor = false;
            this.bCancel.Click += new System.EventHandler(this.bCancel_Click);
            // 
            // bPrintBill
            // 
            this.bPrintBill.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bPrintBill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bPrintBill.Location = new System.Drawing.Point(873, 597);
            this.bPrintBill.Name = "bPrintBill";
            this.bPrintBill.Size = new System.Drawing.Size(193, 52);
            this.bPrintBill.TabIndex = 5;
            this.bPrintBill.Text = "Print delivery note";
            this.bPrintBill.UseVisualStyleBackColor = false;
            this.bPrintBill.Click += new System.EventHandler(this.bPrintBill_Click);
            // 
            // cbPaymentStatus
            // 
            this.cbPaymentStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbPaymentStatus.FormattingEnabled = true;
            this.cbPaymentStatus.Location = new System.Drawing.Point(897, 380);
            this.cbPaymentStatus.Name = "cbPaymentStatus";
            this.cbPaymentStatus.Size = new System.Drawing.Size(169, 37);
            this.cbPaymentStatus.TabIndex = 14;
            this.cbPaymentStatus.SelectedIndexChanged += new System.EventHandler(this.cbPaymentStatus_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(892, 334);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 29);
            this.label1.TabIndex = 15;
            this.label1.Text = "Payment status";
            // 
            // DeliveryNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1078, 661);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbPaymentStatus);
            this.Controls.Add(this.bPrintBill);
            this.Controls.Add(this.bCancel);
            this.Controls.Add(this.bDelete);
            this.Controls.Add(this.grdBill);
            this.Controls.Add(this.bCreateBill);
            this.Controls.Add(this.bShowBill);
            this.Controls.Add(this.grdOrder);
            this.Controls.Add(this.bShowOrder);
            this.Name = "DeliveryNote";
            this.Text = "DeliveryNote";
            ((System.ComponentModel.ISupportInitialize)(this.grdOrder)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdBill)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bShowOrder;
        private System.Windows.Forms.DataGridView grdOrder;
        private System.Windows.Forms.Button bShowBill;
        private System.Windows.Forms.Button bCreateBill;
        private System.Windows.Forms.DataGridView grdBill;
        private System.Windows.Forms.Button bDelete;
        private System.Windows.Forms.Button bCancel;
        private System.Windows.Forms.Button bPrintBill;
        private System.Windows.Forms.ComboBox cbPaymentStatus;
        private System.Windows.Forms.Label label1;
    }
}