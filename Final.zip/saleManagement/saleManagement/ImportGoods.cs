﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saleManagement
{
    public partial class ImportGoods : Form
    {
        private string idAccountant = "";

        DataTable dt = new DataTable();

        List<string> listItem = new List<string>();

        DataTable table = new DataTable();

        public ImportGoods()
        {
            InitializeComponent();
        }

        public ImportGoods(string id)
        {
            InitializeComponent();

            this.idAccountant = id;
            
            //can't write
            cbName.DropDownStyle = ComboBoxStyle.DropDownList;

            loadComboBox();

            table.Columns.Add("NAME", typeof(string));
            table.Columns.Add("PRICE", typeof(int));
            table.Columns.Add("QUANTITY", typeof(int));

            grdListItem.DataSource = table;
        }

        public void loadComboBox()
        {
            dt = SQL.selectQuery("select * from item");

            cbName.DataSource = dt;
            cbName.DisplayMember = "name";
            cbName.ValueMember = "id";
        }

        private void bCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bAdd_Click(object sender, EventArgs e)
        {
            if (cbName.Text == "")
            {
                MessageBox.Show("Please enter name of item");
            }
            else if (txtPrice.Value == 0)
            {
                MessageBox.Show("Please enter price of item");
            }
            else if (txtQuantity.Value == 0)
            {
                MessageBox.Show("Please enter quantity of item");
            }
            else
            {
                listItem.Add(cbName.SelectedValue.ToString() + "," + txtPrice.Value + "," + txtQuantity.Value);

                table.Rows.Add(cbName.Text, txtPrice.Value, txtQuantity.Value);

                grdListItem.DataSource = table;

                cbName.Text = "";
                txtPrice.Value = 0;
                txtQuantity.Value = 0;
            }
        }

        private void bClean_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < listItem.Count; i++)
            {
                table.Rows.RemoveAt(0);
            }

            listItem.Clear();

            grdListItem.DataSource = table;
        }

        private void bImport_Click(object sender, EventArgs e)
        {
            if (listItem.Count == 0)
            {
                MessageBox.Show("Please select at least one item");
                return;
            }

            if (MessageBox.Show("Do you want to IMPORT", "Import", MessageBoxButtons.YesNo) == DialogResult.No)
            {
                return;
            }

            string sql = "select * from receipt";

            dt = SQL.selectQuery(sql);

            string idReceipt = "re" + (dt.Rows.Count + 1);

            DateTime now = DateTime.Now;

            string foundDate = now.ToString();

            sql = "insert into receipt values('" + idReceipt + "', '" + foundDate + "', '" + idAccountant + "', 0)";

            SQL.actionQuery(sql);

            foreach (string Item in listItem)
            {
                string[] components = Item.Split(',');

                sql = "insert into detailReceipt values('" + idReceipt + "', '" + components[0] + "', " + components[1] + ", " + components[2] + ")";

                SQL.actionQuery(sql);
            }

            SQL.updateReceipt();

            MessageBox.Show("IMPORT all items to stock success");
        }
    }
}
