﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saleManagement
{
    public partial class Main : Form
    {
        private Login login = null;
        private string idAccounttant = "";
        public Main()
        {
            InitializeComponent();
        }

        public Main(Login login, string id, string name) : this()
        {
            InitializeComponent();

            this.login = login;
            this.idAccounttant = id;
        }

        private void Main_Load(object sender, EventArgs e)
        {

        }

        private void bLogout_Click(object sender, EventArgs e)
        {
            login.Close();
            this.Close();
        }

        private void bImport_Click(object sender, EventArgs e)
        {
            ImportGoods importGoods = new ImportGoods(idAccounttant);
            importGoods.ShowDialog();
        }

        private void bStatistics_Click(object sender, EventArgs e)
        {
            Statistics statistics = new Statistics();
            statistics.ShowDialog();
        }

        private void bExport_Click(object sender, EventArgs e)
        {
            DeliveryNote deliveryNote = new DeliveryNote(idAccounttant);
            deliveryNote.ShowDialog();
        }
    }
}
