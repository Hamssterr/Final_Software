﻿using System.Data.SqlClient;
using System.Data;
using System.Diagnostics;

namespace saleManagement
{
    internal class SQL
    {
        private static SqlConnection cn;

        public static void connect()
        {
            string s = "initial catalog = saleManagement; data source = LAPTOP-UIV288R8\\SQLEXPRESS01; integrated security = true";
            cn = new SqlConnection(s);
            cn.Open();

        }

        public static void actionQuery(string sql)
        {
            connect();
            SqlCommand cmd = new SqlCommand(sql, cn);

            cmd.ExecuteNonQuery();
        }

        public static DataTable selectQuery(string sql)
        {
            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            return dt;
        }

        //update total price of receipt
        public static void updateReceipt()
        {
            connect();

            string sql = "UPDATE receipt\r\n\tSET totalPrice = T.total\r\n\tFROM receipt LEFT JOIN (\r\n\t\tSELECT r.id, sum(d.price * d.quantity) as total\r\n\t\tFROM receipt r JOIN detailReceipt d ON r.id = d.idReceipt\r\n\t\tGROUP BY r.id\r\n\t) T\r\n\tON receipt.id = T.id";

            SqlCommand cmd = new SqlCommand(sql, cn);

            cmd.ExecuteNonQuery();
        }

        //update total price of order
        public static void updateOrder()
        {
            connect();

            string sql = "UPDATE orders\r\n\tSET totalPrice = T.total\r\n\tFROM orders LEFT JOIN (\r\n\t\tSELECT o.id, sum(d.price * d.quantity) as total\r\n\t\tFROM orders o JOIN detailOrder d ON o.id = d.idOrder\r\n\t\tGROUP BY o.id\r\n\t) T\r\n\tON orders.id = T.id";

            SqlCommand cmd = new SqlCommand(sql, cn);

            cmd.ExecuteNonQuery();
        }

        public static DataTable viewIncomingStock(int month, int year)
        {
            string sql = "select i.name, d.price, d.quantity from receipt r, detailReceipt d, item i\r\nwhere r.id = d.idReceipt and d.idItem = i.id\r\nand month(r.foundDate) = " + month + " and year(r.foundDate) = " + year;

            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            return dt;
        }

        public static DataTable viewOutcomingStock(int month, int year)
        {
            string sql = "select i.name, d.price, d.quantity from orders o, detailOrder d, item i\r\nwhere o.id = d.idOrder and d.idItem = i.id\r\nand month(o.foundDate) = " + month + " and year(o.foundDate) = " + year;

            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            return dt;
        }

        public static DataTable viewBestSelling (int month, int year)
        {
            string sql = "select i.name, sum(d.quantity) as 'selling quantity' from orders o, detailOrder d, item i\r\nwhere o.id = d.idOrder and d.idItem = i.id\r\nand month(o.foundDate) = " + month + " and year(o.foundDate) = " + year + "\r\ngroup by i.name\r\norder by 'selling quantity' desc";

            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            return dt;
        }

        public static DataTable viewRevenueMonthly(int month, int year)
        {
            string sql = "select sum(totalPrice) as revenue from Orders\r\nwhere month(foundDate) = " + month + " and year(foundDate) = " + year;

            connect();
            SqlDataAdapter dataAdapter = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            dataAdapter.Fill(dt);
            return dt;
        }
    }
}
