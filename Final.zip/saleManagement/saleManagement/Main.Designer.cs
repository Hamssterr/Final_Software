﻿namespace saleManagement
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.bLogout = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.bImport = new System.Windows.Forms.Button();
            this.bExport = new System.Windows.Forms.Button();
            this.bStatistics = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bLogout
            // 
            this.bLogout.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.bLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bLogout.Location = new System.Drawing.Point(308, 382);
            this.bLogout.Name = "bLogout";
            this.bLogout.Size = new System.Drawing.Size(180, 40);
            this.bLogout.TabIndex = 3;
            this.bLogout.Text = "Log out";
            this.bLogout.UseVisualStyleBackColor = false;
            this.bLogout.Click += new System.EventHandler(this.bLogout_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(292, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(208, 29);
            this.label1.TabIndex = 7;
            this.label1.Text = "Sale Management";
            // 
            // bImport
            // 
            this.bImport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bImport.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bImport.Location = new System.Drawing.Point(231, 111);
            this.bImport.Name = "bImport";
            this.bImport.Size = new System.Drawing.Size(338, 67);
            this.bImport.TabIndex = 0;
            this.bImport.Text = "Import goods";
            this.bImport.UseVisualStyleBackColor = false;
            this.bImport.Click += new System.EventHandler(this.bImport_Click);
            // 
            // bExport
            // 
            this.bExport.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bExport.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bExport.Location = new System.Drawing.Point(231, 192);
            this.bExport.Name = "bExport";
            this.bExport.Size = new System.Drawing.Size(338, 67);
            this.bExport.TabIndex = 1;
            this.bExport.Text = "Export warehouse";
            this.bExport.UseVisualStyleBackColor = false;
            this.bExport.Click += new System.EventHandler(this.bExport_Click);
            // 
            // bStatistics
            // 
            this.bStatistics.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bStatistics.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bStatistics.Location = new System.Drawing.Point(231, 277);
            this.bStatistics.Name = "bStatistics";
            this.bStatistics.Size = new System.Drawing.Size(338, 67);
            this.bStatistics.TabIndex = 2;
            this.bStatistics.Text = "Statistics";
            this.bStatistics.UseVisualStyleBackColor = false;
            this.bStatistics.Click += new System.EventHandler(this.bStatistics_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.ControlBox = false;
            this.Controls.Add(this.bStatistics);
            this.Controls.Add(this.bExport);
            this.Controls.Add(this.bImport);
            this.Controls.Add(this.bLogout);
            this.Controls.Add(this.label1);
            this.Name = "Main";
            this.Text = "Main";
            this.Load += new System.EventHandler(this.Main_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bLogout;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button bImport;
        private System.Windows.Forms.Button bExport;
        private System.Windows.Forms.Button bStatistics;
    }
}

